<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="background_tile" tilewidth="16" tileheight="16" tilecount="8040" columns="120">
 <image source="background_tile.png" width="1920" height="1080"/>
</tileset>
